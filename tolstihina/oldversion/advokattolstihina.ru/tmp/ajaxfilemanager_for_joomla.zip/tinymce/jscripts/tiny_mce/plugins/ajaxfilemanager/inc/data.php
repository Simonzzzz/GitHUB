{error:'', size:'19.6 KB', atime:'1178102320', ctime:'02/May/2007 22:38:40', mtime:'02/May/2007 22:38:40', path:'../../../uploaded/mailbox_2.gif', name:'mailbox_2.gif', is_writable:'1', is_readable:'1', cssClass:'filePicture', fileType:'image', preview:'1', type:'file', url:'http://localhost/tinymce/uploaded/mailbox_2.gif', tipedit:'Double Click to edit...'}

02/May/2007 22:38:40